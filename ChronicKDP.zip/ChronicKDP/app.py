from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

# Load the model and scaler using pickle
with open('model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

with open('scaler.pkl', 'rb') as scaler_file:
    scaler = pickle.load(scaler_file)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Explicitly fetch input values by their actual form names
        blood_urea = float(request.form.get('blood_urea'))
        blood_glucose = float(request.form.get('Blood Glucose random'))
        anemia = int(request.form.get('anemia'))
        cad = int(request.form.get('coronary_artery_disease'))
        pus_cell = int(request.form.get('pus_cell'))
        rbc = int(request.form.get('red_blood_cells'))
        diabetes = int(request.form.get('diabetesmellitus'))
        edema = int(request.form.get('pedal_edema'))

        # Put into numpy array for prediction
        input_data = np.array([[blood_urea, blood_glucose, anemia, cad, pus_cell, rbc, diabetes, edema]])
        input_scaled = scaler.transform(input_data)
        result = model.predict(input_scaled)[0]
        
        output = "Chronic Kidney Disease (CKD)" if result == 1 else "Not CKD"
        return render_template('result.html', prediction=output)
    except Exception as e:
        return f"Error: {e}"

@app.route('/form1')
def form1():
    return render_template('index1.html')

if __name__ == "__main__":
    app.run(debug=True)
